package be.odisee.medec.dao;

import be.odisee.medec.domain.Activiteit;
import org.springframework.data.repository.CrudRepository;

public interface ActiviteitRepository extends CrudRepository<Activiteit,Long> {

}

