package be.odisee.medec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.Date;

@SpringBootApplication
public class MedecApplication {

	public static void main(String[] args) {

		SpringApplication.run(MedecApplication.class, args);
	}

}
